<?php
    require_once 'controladores/Controlador.php';
    require_once 'vistas/Vista.php';
    require_once 'modelos/M_Usuarios.php';
    
    class C_Usuarios extends Controlador{

        private $modelo;
        
        public function __construct(){
            parent::__construct();
            $this -> modelo = new M_Usuarios();
        }

        public function validarUsuario($filtros){
            $valido='N';
            $usuarios=$this -> modelo -> buscarUsuarios($filtros);

            if (!empty($usuarios)) {
                $valido = 'S';
                $_SESSION['usuario'] = $usuarios[0]['login'];
            }
            return $valido;
        }

        public function getVistaUsuarios($filtros=array()){
            $usuarios=$this -> modelo -> buscarUsuarios($filtros);
           Vista::render('vistas/Usuarios/V_Usuarios.php');

        }
        public function getVistaUsuarioss($filtros) {
            if (isset($filtros['id'])) {
                $usuarios=$this -> modelo -> getUser($filtros);
                if (!empty($usuarios)) {
                    Vista::render('vistas/Usuarios/V_Crear_Usuario.php', ['usuario' => $usuarios]);
                } else {
                    Vista::render('vistas/Usuarios/V_Crear_Usuario.php');

                }
            } else {
                echo "ID de usuario no proporcionado";
            }
        }
        public function buscarUsuarios($filtros=array()){
            $usuarios=$this -> modelo -> buscarUsuarios($filtros);
            Vista :: render('vistas/Usuarios/V_Usuarios_Listado.php', array('usuarios'=> $usuarios));
        }

        public function actualizarUser($campos=array()){
            $usuarios=$this -> modelo -> actualizarUser($campos);
            //Vista :: render('vistas/Usuarios/V_Usuarios_Listado.php');

        }

        public function insertarUser($campos1=array()){
            $usuarios=$this -> modelo -> insertarUser($campos1);
            Vista :: render('vistas/Usuarios/V_Usuarios_Listado.php', array('usuarios'=> $usuarios));

        }
   
       
    }
?>