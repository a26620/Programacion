<?php
header('Content-Type: application/json');
require_once 'modelos/Modelo.php';
require_once 'modelos/DAO.php';
class M_Usuarios extends Modelo
{
    public $DAO;
    public function __construct()
    {
        parent::__construct();
        $this->DAO = new DAO();
    }
    public function buscarUsuarios($filtros = array())
    {

        $b_texto = '';
        $usuario = ''; //login
        $pass = '';
        $sexo = '';
        $activo = '';
        extract($filtros);

        $SQL = "SELECT * FROM usuarios WHERE 1=1";
        $SQL2 = "SELECT apellidos1 FROM usuarios WHERE 1=1";

        if ($usuario != '' && $pass != '') {
            $usuario = addslashes($usuario); // añade \ delante de caract especiales como la ', "" para que pierdan funcionalidad
            $pass = addslashes($pass);
            $SQL .= " AND login = '$usuario' AND pass = MD5('$pass') ";
        }


        if ($b_texto != '') {
            $aTexto = explode(' ', $b_texto);
            $SQL .= " AND (1=2";

            foreach ($aTexto as $palabra) {
                $SQL .= " OR apellido_1 LIKE '%$palabra%'";
                $SQL .= " OR apellido_2 LIKE '%$palabra%'";
                $SQL .= " OR nombre LIKE '%$palabra%'";
            }
            $SQL .= " ) ";

        }

        if ($sexo === 'H' || $sexo === 'M') {
            $SQL .= " AND sexo = '$sexo'";
        }

        if ($activo === 'S' || $activo === 'N') {
            $SQL .= " AND activo = '$activo'";
        }

        if ($b_texto != '') {
            $aTexto = explode(' ', $b_texto);
            $SQL .= " AND (1=2";

            foreach ($aTexto as $palabra) {
                $SQL .= " OR apellido_1 LIKE '%$palabra%'";
                $SQL .= " OR apellido_2 LIKE '%$palabra%'";
                $SQL .= " OR nombre LIKE '%$palabra%'";
            }
            $SQL .= " ) ";

        }

        // echo $SQL;

        $usuarios = $this->DAO->consultar($SQL);
        return $usuarios;
    }
    public function actualizarUser($campos = array()) {
        extract($campos);
    
        // Construye tu consulta SQL
        $SQL = "UPDATE usuarios SET ";
        $SQL .= "nombre = '$nombre', ";
        $SQL .= "apellido_1 = '$apellido_1', ";
        $SQL .= "apellido_2 = '$apellido_2', ";
        $SQL .= "sexo = '$sexo', ";
        $SQL .= "mail = '$mail', ";
        $SQL .= "movil = '$movil', ";
        $SQL .= "activo = '$activo' ";
        $SQL .= "WHERE id_Usuario = $id_usuario";
    
        // Ejecutar la actualización
        $resultado = $this->DAO->actualizar($SQL);
    
        // Prepara la cabecera HTTP para respuesta JSON
        header('Content-Type: application/json');
    
        // Verificar y enviar la respuesta
        if ($resultado) {
            // Si la actualización fue exitosa
            echo json_encode(['exito' => 'Actualización realizada correctamente.']);
        } else {
            // Si hubo un error en la actualización
            echo json_encode(['error' => 'Error al actualizar el usuario.']);
        }
    }
     

    public function insertarUser($campos1 = array())
    {
        extract($campos1);
        $errores = [];
        // Validaciones obligatorias
        if (empty($nombre) || empty($apellido_1) || empty($apellido_2) || empty($sexo) || empty($mail) || empty($movil) || empty($login) || empty($pass)) {
            $errores[] = "Todos los campos son obligatorios.";
        }

        // Validar el correo electrónico
        if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
            $errores[] = "El formato del correo electrónico no es válido.";
        }

        // Validar la contraseña
        if (strlen($pass) < 8 || !preg_match('/[A-Z]/', $pass) || !preg_match('/[a-z]/', $pass) || !preg_match('/[0-9]/', $pass) || !preg_match('/[!@#$%^&*.]/', $pass)) {
            $errores[] = "La contraseña debe tener al menos 8 caracteres y contener al menos una letra mayúscula, una letra minúscula, un número y un carácter especial.";
        }

        // Verificar si el login ya está en uso
        $consulta = "SELECT COUNT(*) as total FROM usuarios WHERE login = '$login'";
        $resultado = $this->DAO->consultar($consulta);
        $totalUsuarios = $resultado[0]['total'];

        if ($totalUsuarios > 0) {
            $errores[] = "Ya existe un usuario con el mismo nombre de usuario.";
        }

        if (!empty($errores)) {
            echo json_encode(['errores' => $errores]);
            return;
        }
        $SQL = "INSERT INTO usuarios (nombre, apellido_1, apellido_2, sexo, fecha_Alta, mail, movil, login, pass, activo) VALUES ";
        $SQL .= "('$nombre', '$apellido_1', '$apellido_2', '$sexo', NOW(), '$mail', '$movil', '$login', md5('$pass'), '$activo')";

        // Ejecutar la consulta SQL aquí
        $resultado = $this->DAO->insertar($SQL);

        if ($resultado) {
            // Inserción exitosa
            echo json_encode(['exito' => 'Usuario insertado correctamente.']);
        } else {
            // Error en la inserción
            echo json_encode(['errores' => ['Error al insertar el usuario.']]);        }
    }

    public function getUser($filtros = array())
    {
        $usuario = '';
        $pass = '';
        $sexo = '';
        $id = '';
        extract($filtros);

        $SQL = "SELECT * FROM usuarios WHERE 1=1";

        if ($usuario != '') {
            $usuario = addslashes($usuario);
            $SQL .= " AND login = '$usuario' ";
        }

        if ($pass != '') {
            $pass = md5($pass);
            $pass = addslashes($pass);
            $SQL .= " AND pass = '$pass' ";
        }

        if ($id != '') {
            $id = addslashes($id);
            $SQL .= " AND id_Usuario = '$id' ";
        }
        $usuarios = $this->DAO->consultar($SQL);
        return $usuarios;
    }

}



?>