<?php session_start();
    if(isset($_SESSION['usuario']) && $_SESSION['usuario']!=''){
        //esta logeado
    }else{
        header('Location: login.php');
    }
?>
<!DOCTYPE html>
<html lang="es">
<html>
    <head>
    <title>Página Principal</title>
        <meta name="viewport" 
            content="width=device-width, initial-scale=1.0">
            <link rel="icon" type="image/x-icon" href="/imagenes/encabezado.png">

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
        <script src="js/app.js"></script>
        <script src="js/Usuarios.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <link rel="stylesheet" href="css/index.css">
        <link rel="stylesheet" href="css/menu.css">
        <link rel="stylesheet" href="css/usuarios.css">


    </head>
    <body>
    <style>
  
    .divLogotipo img {
      max-width: 100%;
      height: auto;
    }
    .divTituloApp {
        margin-top: 10px;
    
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5em;
      font-weight: bold;
    }
    .divLog a {
      margin-top: 19px;
      display: flex;
      align-items: center;
      justify-content: space-between;

      
    }
    .divLog img {
      max-width: 30px;
      height: auto;
      margin-left: 10px;
    }
    .divLog i {
      font-size: 1.5em;
      margin-right: 10px;
    }
  </style>
</head>
<body>
  
<section id="secEncabezadoPagina" class="container-fluid">
  <div class="row">
    <div class="divLogotipo col-lg-2 col-md-2 col-sm-10">
      <a href="index.php"><img src="imagenes/logo.png" alt="Logotipo"></a>
    </div>
    <div class="divTituloApp col-lg-8 col-md-8 d-none d-md-block">
      Alejandro Cerqueira Navarro
    </div>
    <div class="divLog col-lg-2 col-md-2 col-sm-2">
    <?php
        if(isset($_SESSION['usuario'])) {
        echo '<a href="logout.php" title="Salir" style="text-decoration:none;">';
        echo htmlspecialchars($_SESSION['usuario']);
        echo '<i class="fas fa-sign-out-alt" style="color:#2A6C1E;"></i>';
        echo '</a>';
        } else {
        echo '<a href="login.php" title="Entrar">';
        echo '<i class="fas fa-user" style="color:#2A6C1E;"></i>';
        echo '</a>';
        }
        ?>

    </div>
  </div>

        <section id="secMenuPagina" class="container-fluid">
  <nav class="navbar navbar-expand-sm navbar-light" style="background-color: #2A6C1E;" aria-label="Fourth navbar example">
    <div class="container-fluid">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse " id="navbarsExample04">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="#"><i class="fas fa-home me-2"></i>Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="#"><i class="fas fa-link me-2"></i>Link</a>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled"><i class="fas fa-ban me-2"></i>Disabled</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-white" href="#" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-database me-2"></i>CRUD's</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item " href="#" onclick="getVistaMenuSeleccionado('Usuarios', 'getVistaUsuarios')"><i class="fas fa-user me-2" ></i>Usuarios</a></li>
              <li><a class="dropdown-item" href="#" onclick="getVistaMenuSeleccionado('Pedidos', 'getVistaPedidos')"><i class="fas fa-shopping-cart me-2" ></i>Pedidos</a></li>
              <li><a class="dropdown-item" href="#"><i class="fas fa-ellipsis-h me-2"></i>Something else here</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</section>    
                   
        <section id="secContenidoPagina" class="container-fluid">

        </section>
        
        <script src="librerias/bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
    </body>

</html>