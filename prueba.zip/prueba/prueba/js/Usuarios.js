
function buscarUsuarios() {
    let opciones = { method: "GET" };
    let parametros = "controlador=Usuarios&metodo=buscarUsuarios";
    parametros += "&" + new URLSearchParams(new FormData(document.getElementById("formularioBuscar"))).toString();
    console.log(parametros);

    fetch("C_Ajax.php?" + parametros, opciones)
        .then(res => {
            if (res.ok) {
                console.log('respuesta ok');
                return res.text();
            }
        })
        .then(vista => {
            document.getElementById("capaResultadoBusqueda").style.display = "block";
            document.getElementById("capaResultadoBusqueda").innerHTML = vista;
            document.getElementById("capaEditarCrearUsuarios").style.display = "none";

        })
        .catch(err => {
            console.log("Error al realizar la petición", err.message);
        });

}


function cargarVistaEdicion(id) {
    let opciones = { method: "GET" };
    let parametros = "controlador=Usuarios&metodo=getVistaUsuarioss&id="+id;
    console.log(parametros);

    fetch("C_Ajax.php?" + parametros, opciones)
        .then(res => {
            if (res.ok) {
                console.log('respuesta ok');
                return res.text();
            }
        })
        .then(vista => {
            document.getElementById("capaResultadoBusqueda").style.display = "none";
            document.getElementById("capaEditarCrearUsuarios").style.display = "block";
            document.getElementById("capaEditarCrearUsuarios").innerHTML = vista;
        })
        .catch(err => {
            console.log("Error al realizar la petición", err.message);
        });
}

function InsertarEditarUsuario(event) {
    event.preventDefault();
    let idUsuarioElement = document.getElementById("id_usuario");
    let idUsuario = idUsuarioElement ? idUsuarioElement.value.trim() : '';
    let estaEditando = idUsuario !== '';
    // Obtener los valores de los campos del formulario
    let nombre = document.getElementById("nombre");
    let apellido1 = document.getElementById("apellido_1");
    let apellido2 = document.getElementById("apellido_2");
    let mail = document.getElementById("mail");
    let login = document.getElementById("login");
    let pass = document.getElementById("pass");
    let pass2 = document.getElementById("pass2");
    let sexo = document.getElementById("sexos");
    let activo = document.getElementById("activo");
    // Definir mensajes de error personalizados para cada campo
    let errores = {
        nombre: "Nombre",
        apellido_1: "Primer Apellido",
        apellido_2: "Segundo Apellido",
        mail: "Correo Electrónico",
        mailNoValid: "El correo electrónico no tiene un formato válido",
        login: "Login",
        pass: "Contraseña",
        passConfirm: "La contraseña debe tener al menos 8 caracteres y contener al menos una letra mayúscula, una letra minúscula, un número y un carácter especial.",
        pass2: "Las contraseñas no coinciden",
        activo: "Activo",
        sexo: "Sexo"
    };  
    // Validar campos obligatorios
    let camposConErrores = [];
    if (!nombre || nombre.value === '') {
        camposConErrores.push("nombre");
    }
    if (!apellido1 || apellido1.value.trim() === '') {
        camposConErrores.push("apellido_1");
    }
    if (!apellido2 || apellido2.value.trim() === '') {
        camposConErrores.push("apellido_2");
    }
    if (!mail || mail.value.trim() === '') {
        camposConErrores.push("mail");
    }
    if (!login || login.value.trim() === '') {
        camposConErrores.push("login");
    }
    if (!pass || pass.value.trim() === '') {
        camposConErrores.push("pass");
    }
    if (!sexo || sexo.value.trim() === '') {
        camposConErrores.push("sexo");
    }
    if (!activo || activo.value.trim() === '') {
        camposConErrores.push("activo");
    }

    if (mail.value.trim() !== '') {
        if (!/^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/.test(mail.value)) {
            camposConErrores.push("mailNoValid");
        }
    }
    // Validar la contraseña
    if (!estaEditando) {
        if (pass.value.trim() !== '') {
            // Agregar aquí las reglas de complejidad para la contraseña
            if (pass.value.length < 8 ||
                !/[!@#$%^&*.]/.test(pass.value) ||
                !/[\d]/.test(pass.value) ||
                (!/[A-Z]/.test(pass.value) || !/[a-z]/.test(pass.value))) {
                camposConErrores.push("passConfirm");
            }
        }
        if (pass2.value.trim() !== '') {
            if (pass.value.trim() !== pass2.value.trim()) {
                camposConErrores.push("pass2");
            }
        }
    }
    // Mostrar mensajes de error para campos con errores
    if (camposConErrores.length > 0) {
        let mensajeError = "Los siguientes campos son obligatorios o no cumplen con los requisitos:\n";
        for (let campo of camposConErrores) {
            mensajeError += `- ${errores[campo]}\n`;
        }

        Swal.fire({
            title: ' Algunos Campos Están Incompletos!',
            text: mensajeError,
            icon: 'error',
            confirmButtonText: 'Cerrar'
        });
        return;



    } else {

        let metodo = estaEditando ? 'actualizarUser' : 'insertarUser';
        let mensajeExito = idUsuario ? 'Usuario actualizado correctamente' : 'Usuario creado correctamente';
        let opciones = { method: "POST" };
        let parametros = "controlador=Usuarios&metodo=" + metodo;
        parametros += "&" + new URLSearchParams(new FormData(document.getElementById("formularioCrearUsuario"))).toString();
        console.log(parametros);
        fetch("C_Ajax.php?" + parametros, opciones)
        .then(response => {
            if (!response.ok) {
                throw new Error('Respuesta no OK del servidor');
            }
            return response.json();
        })
        .then(data => {
            if (data.errores && data.errores.length > 0) {
                let mensajeError = data.errores.join('\n');
                Swal.fire({
                    title: 'Error!',
                    text: mensajeError,
                    icon: 'error',
                    confirmButtonText: 'Cerrar'
                });
                return;
            

            }
    
            // Si no hay errores, muestra el mensaje de éxito
            Swal.fire({
                title: 'Éxito!',
                text: mensajeExito,
                icon: 'success',
                confirmButtonText: 'Genial',
            });
            buscarUsuarios();
           // document.getElementById("capaEditarCrearUsuarios").style.display = "none";


            })
            .catch(err => {
                console.log("Error al realizar la petición", err.message);

                Swal.fire({
                    title: 'Error!',
                    text: 'Usuario no registrado correctamente',
                    icon: 'error',
                    confirmButtonText: 'Cerrar'
                });
            });

    }
}



function volveratras() {
    getVistaMenuSeleccionado('Usuarios', 'getVistaUsuarios');
}
