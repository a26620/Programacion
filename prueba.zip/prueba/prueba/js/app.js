function cargarUnScript(url){
    let script = document.createElement('script');
    script.src = url;
    document.head.appendChild(script);
}


function getVistaMenuSeleccionado(controlador, metodo, id){
    let opciones={method: "GET"};
    let parametros= "controlador="+controlador+"&metodo="+metodo+"&id="+id;
    fetch("C_Ajax.php?"+parametros, opciones)
        .then(res => {
            if(res.ok){
                console.log('respuesta ok');
                return res.text();
            }
        })
        .then(vista=>{
            document.getElementById("secContenidoPagina").innerHTML=vista;
            cargarUnScript('js/'+controlador+'.js');
        })
        .catch(err=>{
            console.log("Error al realizar la petición", err.message);
        });

}