<?php
session_start();
$usuario = '';
$pass = '';
extract($_POST);
 
if ($usuario == '' || $pass == '') {
    $mensa = 'Completa los campos';
} else {
    require_once 'controladores/C_Usuarios.php';
    $objUsuarios = new C_Usuarios();
    $resultado = $objUsuarios->validarUsuario(array(
        'usuario' => $usuario,
        'pass' => $pass
    ));
 
    if ($resultado == 'S') {
        header('Location: index.php');
    } else {
      $mensa = 'Datos incorrectos';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/x-icon" href="/imagenes/encabezado.png">

  <title>Applastic</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .login {
      min-height: 100vh;
    }

    .bg-image {
      background-image: url('https://images.unsplash.com/photo-1507629221898-576a56b530bb?ixlib=rb-4.0.3&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max');
      background-size: cover;
      background-position: center;
    }

    .login-heading {
      font-weight: 300;
    }

    .btn-login {
      font-size: 0.9rem;
      letter-spacing: 0.05rem;
      padding: 0.75rem 1rem;
    }

   

    .logo {
      width: 100px;
      height: 100px;
      background-color: #2A6C1E;
      border-radius: 50%;
      margin: 0 auto 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2em;
    }
  </style>
</head>

<body>
  <div class="container-fluid ps-md-0">
    <div class="row g-0">
      <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
      <div class="col-md-8 col-lg-6">
        <div class="login d-flex align-items-center py-5">
          <div class="container">
            <div class="row">
              <div class="col-md-9 col-lg-8 mx-auto">
                <div class="logo">
                  <img src="imagenes/logo.png" alt="">
                </div>
                <h3 class="login-heading mb-4">Bienvenido de nuevo!</h3>

                <!-- Formulario de Inicio de Sesión -->
                <form id="formularioLogin" name="formularioLogin" method="post" >
                  <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Usuario"
                      value="<?php echo htmlspecialchars($usuario); ?>">
                    <label for="usuario">Usuario:</label>
                  </div>
                  <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="pass" name="pass" placeholder="Contraseña">
                    <label for="pass">Contraseña:</label>
                  </div>
                  <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="rememberMe" name="rememberMe">
                    <label class="form-check-label" for="rememberMe">Recordar contraseña</label>
                  </div>
                  <span id="msj" class="form-text text-danger">
                    <?php echo $mensa; ?>
                  </span>
                  <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-login text-uppercase fw-bold mb-2"
                      style="background-color: #2e5d23; border-color: #2A6C1E;">
                      <i class="fa fa-sign-in" style="color: white;"></i> Entrar
                    </button>
                    <!-- <div class="text-center">
                      <a class="small" href="#">¿Olvidaste la contraseña?</a>
                    </div> -->
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"> </script>
  <script>
  window.onload = function() {
    var mensaje = "<?php echo htmlspecialchars($mensa); ?>";
    if (mensaje !== "") {
      document.getElementById("msj").textContent = mensaje;
    }
  };
</script>
  </head>
</body>

</html>