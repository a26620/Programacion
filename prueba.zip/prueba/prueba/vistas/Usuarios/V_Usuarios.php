<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Horizontal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-3">
        <form id="formularioBuscar" name="formularioBuscar" class="row g-3 align-items-center"  onsubmit="crearUsuario(event)">
            <div class="col-auto">
                <label id="nombre" for="b_texto" class="col-form-label">Nombre:</label>
            </div>
            <div class="col-auto">
                <input type="text" id="b_texto" name="b_texto" class="form-control" onkeyup="buscarUsuarios()">
            </div>
            <div class="col-auto">
                <label for="sexo" class="col-form-label">Sexo:</label>
            </div>
            <div class="col-auto">
                <select name="sexo" id="sexo" class="form-select" onchange="buscarUsuarios()">
                    <option value="">Todos</option>
                    <option value="H">Hombre</option>
                    <option value="M">Mujer</option>
                </select>
            </div>
            <div class="col-auto">
                <div class="form-check">
                    <input type="radio" name="activo" id="todos" class="form-check-input" autocomplete="off" onchange="buscarUsuarios()" checked>
                    <label class="form-check-label" for="todos">Todos</label>
                </div>
            </div>
            <div class="col-auto">
                <div class="form-check">
                    <input type="radio" name="activo" id="activos" class="form-check-input" value="S" autocomplete="off" onchange="buscarUsuarios()">
                    <label class="form-check-label " for="activos">Activos</label>
                </div>
            </div>
            <div class="col-auto">
                <div class="form-check">
                    <input type="radio" name="activo" id="inactivos" class="form-check-input" value="N" autocomplete="off" onchange="buscarUsuarios()">
                    <label class="form-check-label" for="inactivos">Inactivos</label>
                </div>
            </div>
       
              <input type="button" onclick="cargarVistaEdicion()" value="Añadir Usuario"/>

        </form>
        <div id="capaResultadoBusqueda">
        </div>
        <div id="capaEditarCrearUsuarios">
        </div>

        

</div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js">
        </script>
    

    
</body>



</html>