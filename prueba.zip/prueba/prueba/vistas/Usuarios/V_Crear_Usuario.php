<!DOCTYPE html>
<html lang="en">
<?php
$usuario = $datos['usuario'];
?>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tabla de Usuarios</title>
  <link rel="stylesheet" href="css/bootstrap.css">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script src="js/Usuarios.js"></script>


</head>

<body>

  <style>
    .login {
      min-height: 100vh;
    }

    .bg-image {
      background-image: url('https://images.unsplash.com/photo-1597348989645-46b190ce4918?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D');
      background-size: cover;
      background-position: center;
    }

    .login-heading {
      font-weight: 300;
    }

    .btn-login {
      font-size: 0.9rem;
      letter-spacing: 0.05rem;
      padding: 0.75rem 1rem;
    }



    .logo {
      width: 100px;
      height: 100px;
      background-color: #2A6C1E;
      border-radius: 50%;
      margin: 0 auto 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2em;
    }
  </style>
  <?php

  //echo $usuario[0]['id_Usuario'];
  
  // Comprobando si existe el ID del usuario
  if (isset($usuario[0]['id_Usuario'])) {

    ?>
    <div class="container-fluid ps-md-0">
      <div class="row g-0">
        <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
        <div class="col-md-8 col-lg-6">
          <div class="login d-flex align-items-center py-5">
            <div class="container">
              <div class="row">
                <div class="col-md-9 col-lg-8 mx-auto">
                  <div class="logo">
                    <img src="imagenes/logo.png" alt="">
                  </div>
                  <h3 class="login-heading mb-4"> <strong>Actualiza un usuario!</strong></h3>

                  <form id="formularioCrearUsuario" name="formularioCrearUsuario" onsubmit="InsertarEditarUsuario(event)">
                    <input type="hidden" id="id_usuario" name="id_usuario"
                      value="<?php echo $usuario[0]['id_Usuario'] ?? ''; ?>">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre"
                        value="<?php echo isset($usuario[0]['nombre']) ? $usuario[0]['nombre'] : ''; ?>">
                      <label for="usuario">Nombre:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="apellido_1" name="apellido_1"
                        placeholder="Primer Apellido"
                        value="<?php echo isset($usuario[0]['apellido_1']) ? $usuario[0]['apellido_1'] : ''; ?>">
                      <label for="apellido_1">Primer Apellido:</label>
                    </div>

                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="apellido_2" name="apellido_2"
                        placeholder="Segundo Apellido"
                        value="<?php echo isset($usuario[0]['apellido_2']) ? $usuario[0]['apellido_2'] : ''; ?>">
                      <label for="apellido_2">Segundo Apellido:</label>
                    </div>

                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="mail" name="mail" placeholder="Correo Electrónico"
                        value="<?php echo isset($usuario[0]['mail']) ? $usuario[0]['mail'] : ''; ?>">
                      <label for="mail">Correo Electrónico:</label>
                    </div>

                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="movil" name="movil" placeholder="Teléfono Móvil"
                        value="<?php echo isset($usuario[0]['movil']) ? $usuario[0]['movil'] : ''; ?>">
                      <label for="movil">Teléfono Móvil:</label>
                    </div>

                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="login" name="login" placeholder="Usuario"
                        value="<?php echo isset($usuario[0]['login']) ? $usuario[0]['login'] : ''; ?>">
                      <label for="login">Usuario:</label>
                    </div>

                    <div class="form-floating mb-3">
                      <input type="password" class="form-control" id="pass" name="pass" readonly placeholder="Contraseña"
                        value="<?php echo isset($usuario[0]['pass']) ? $usuario[0]['pass'] : ''; ?>">
                      <label for="pass">Contraseña:</label>
                    </div>
                    <!-- 
<div class="form-floating mb-3">
  <input type="password" class="form-control" id="pass2" name="pass2" placeholder="Repetir Contraseña"
    value="<?php echo isset($usuario[0]['pass2']) ? $usuario[0]['pass2'] : ''; ?>">
  <label for="pass2">Repetir Contraseña:</label>
</div> -->

                    <div class="form-floating mb-3">
                      <select class="form-select" id="sexos" name="sexo">
                        <option value="H" <?php echo (isset($usuario[0]['sexo']) && $usuario[0]['sexo'] == 'H') ? 'selected' : ''; ?>>Masculino</option>
                        <option value="M" <?php echo (isset($usuario[0]['sexo']) && $usuario[0]['sexo'] == 'M') ? 'selected' : ''; ?>>Femenino</option>
                      </select>
                      <label for="sexo">Sexo:</label>
                    </div>


                    <!-- Elemento select para seleccionar la actividad -->
                    <div class="form-floating mb-3">
                      <select class="form-select" id="activo" name="activo">
                        <option value="S" selected>Activo</option>
                        <option value="N">Inactivo</option>
                      </select>
                      <label for="actividad">Actividad:</label>
                    </div>
                    <span id="msj" class="form-text text-danger">
                      <?php echo htmlspecialchars($mensa); ?>
                    </span>
                    <div class="d-grid">
                      <input type="submit" onclick="InsertarEditarUsuario()" value="Actualizar Usuario"
                        style="background-color: #2e5d23; border-color: #2A6C1E;"
                        class="btn btn-primary btn-login text-uppercase fw-bold mb-2" />
                      <input type="button" onclick="volveratras()" value="Volver"
                        class="btn btn-primary btn-login text-uppercase fw-bold mb-2"
                        style="background-color: gray; border-color: gray;">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
  } else {
    ?>
    <div class="container-fluid ps-md-0">
      <div class="row g-0">
        <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
        <div class="col-md-8 col-lg-6">
          <div class="login d-flex align-items-center py-5">
            <div class="container">
              <div class="row">
                <div class="col-md-9 col-lg-8 mx-auto">
                  <div class="logo">
                    <img src="imagenes/logo.png" alt="">
                  </div>
                  <h3 class="login-heading mb-4"> <strong>Añade un usuario!</strong></h3>

                  <form id="formularioCrearUsuario" name="formularioCrearUsuario" onsubmit="InsertarEditarUsuario(event)">
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre">
                      <label for="usuario">Nombre:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="apellido_1" name="apellido_1"
                        placeholder="Primer Apellido">
                      <label for="usuario">Primer Apellido:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="apellido_2" name="apellido_2"
                        placeholder="Segundo Apellido">
                      <label for="usuario">Segundo Apellido:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="mail" name="mail" placeholder="Usuario">
                      <label for="usuario">Correo Electrónico:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="movil" name="movil" placeholder="Usuario">
                      <label for="usuario">Teléfono Móvil:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="login" name="login" placeholder="Usuario">
                      <label for="usuario">Usuario:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="password" class="form-control" id="pass" name="pass" placeholder="Usuario">
                      <label for="usuario">Contraseña:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="password" class="form-control" id="pass2" name="pass2" placeholder="Contraseña">
                      <label for="pass"> Repetir Contraseña:</label>
                    </div>
                    <div class="form-floating mb-3">
                      <select class="form-select" id="sexos" name="sexo">
                        <option value="" selected disabled hidden></option>

                        <option value="H">Masculino</option>
                        <option value="M">Femenino</option>
                      </select>
                      <label for="sexo">Sexo:</label>
                    </div>

                    <!-- Elemento select para seleccionar la actividad -->
                    <div class="form-floating mb-3">
                      <select class="form-select" id="activo" name="activo">
                        <option value="S" selected>Activo</option>
                        <option value="N">Inactivo</option>
                      </select>
                      <label for="actividad">Actividad:</label>
                    </div>
                    <span id="msj" class="form-text text-danger">
                      <?php echo htmlspecialchars($mensa); ?>
                    </span>
                    <div class="d-grid">
                      <input type="submit" onclick="InsertarEditarUsuario()" value="Crear Usuario"
                        style="background-color: #2e5d23; border-color: #2A6C1E;"
                        class="btn btn-primary btn-login text-uppercase fw-bold mb-2" />
                      <input type="button" onclick="volveratras()" value="Volver"
                        class="btn btn-primary btn-login text-uppercase fw-bold mb-2"
                        style="background-color: gray; border-color: gray;">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
  }
  ?>

</body>



</html>