<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tabla de Usuarios</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <script src="js/Usuarios.js"></script>

</head>

<body>


  <div class="container mt-3">
    
    <?php
    $usuarios = isset($datos['usuarios']) && is_array($datos['usuarios']) ? $datos['usuarios'] : array();

    // $usuarios = $datos['usuarios'];
    if (count($usuarios) > 0) :
    ?>
        <table class="table table-success table-striped" id="tablaUsuarios">
        
          <thead>
            <tr>

              <th scope="col">ID</th>
              <th scope="col">Nombre</th>
              <th scope="col">Primer Apellido</th>
              <th scope="col">Segundo Apellido</th>
              <th scope="col" class="text-center">Sexo</th>
              <th scope="col" class="text-center">Fecha de Alta</th>
              <th scope="col">Correo Electrónico</th>
              <th scope="col">Teléfono Móvil</th>
              <th scope="col" class="text-center">Actividad</th>
              <th scope="col" class="text-center">Acciones</th>

            </tr>
          </thead>
          <tbody>
            <?php foreach ($usuarios as $usuario) : ?>
              <tr>
                <td><?php echo htmlspecialchars(ucwords($usuario['id_Usuario'])); ?></td>
                <td><?php echo htmlspecialchars(ucwords($usuario['nombre'])); ?></td>
                <td><?php echo htmlspecialchars(ucwords($usuario['apellido_1'])); ?></td>
                <td><?php echo htmlspecialchars(ucwords($usuario['apellido_2'])); ?></td>

                <td class="text-center"><?php echo htmlspecialchars($usuario['sexo']); ?></td>
                <td class="text-center">
                  <?php
                  if ($usuario['fecha_Alta'] == '0000-00-00') {
                    echo "No hay fecha de alta";
                  } else {
                    $fecha = DateTime::createFromFormat('Y-m-d', $usuario['fecha_Alta']);
                    echo htmlspecialchars($fecha->format('d/m/Y'));
                  }
                  ?>
                </td>
                <td><?php echo htmlspecialchars($usuario['mail']); ?></td>
                <td><?php echo htmlspecialchars($usuario['movil']); ?></td>
                <td class="text-center">
                  <?php echo htmlspecialchars($usuario['activo']); ?>
                </td>
                <td class="text-center">
                <input type="button" class="btn btn-primary" onclick="cargarVistaEdicion(<?php echo $usuario['id_Usuario']; ?>)"  value="Editar"/> 
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
    <?php else : ?>
      <p>No se han encontrado usuarios de acuerdo con tu búsqueda.</p>
    <?php endif; ?>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Agrega esto al final del cuerpo del documento -->


</body>

</html>