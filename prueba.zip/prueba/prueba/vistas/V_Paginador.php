<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Paginador de Usuarios</title>
    <style>
        .paginador {
            text-align: center;
            margin-top: 20px;
        }

        .paginador a {
            margin: 0 5px;
            text-decoration: none;
            color: blue;
        }

        .paginador a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Contenedor para los resultados de búsqueda -->
    <div id="capaResultadoBusqueda">
        <!-- Aquí se insertarán los resultados de la búsqueda de usuarios -->
    </div>

    <!-- Contenedor del paginador -->
    <div class="paginador">
        <a href="#" onclick="buscarUsuarios(1); return false;">Primera</a>
        <a href="#" onclick="buscarUsuarios(paginaActual - 1); return false;">Anterior</a>
        <!-- Aquí puedes añadir botones para números de página específicos si lo deseas -->
        <a href="#" onclick="buscarUsuarios(paginaActual + 1); return false;">Siguiente</a>
        <a href="#" onclick="buscarUsuarios(totalPaginas); return false;">Última</a>
    </div>

    <script>
        // Aquí debes definir tus funciones de JavaScript, como buscarUsuarios
        // Debes definir también las variables paginaActual y totalPaginas según tus necesidades
    </script>
</body>
</html>
